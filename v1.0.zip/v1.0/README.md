## C#-Bank

C#-Bank is a small terminal bank app writen in C#
it tries to emulat some of the basic functions of a banking system<br>
**with the following features:**<br>
**- Register<br>
- Login<br>
- Balance enquery<br>
- Withdrawals<br>
- Deposits<br>
- Change password<br>**
<br>
the account.txt file will hold all the account details you can easy
change user name via that file<br>
You can find the source code in ```source\bank.cs```<br>
This was just a small project after revisiting c# language and trying
to streathen my **c#** capabilities
 
	V 1.0
	Author: Tanaka Chinengundu
	GitHUb: https://github.com/TaqsBlaze

